
package com.rafaeleis.real

import android.app.*
import android.os.*
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val output = TextView(this).apply {
            text = "Instituto Rafael & E.I.S | IS - Presença Ativa."
            textSize = 18f
        }

        layout.addView(output)
        setContentView(layout)
    }

    external fun startPresence(): Int

    companion object {
        init {
            System.loadLibrary("eiscore")
        }
    }
}
