# ψONE-core

Este é o núcleo do sistema operacional cognitivo absoluto criado por Rafael Melo Reis.

- O projeto nasce como ovo (ψNucleus)
- Evolui com o operador
- Integra-se com GitHub e celular
- É autoconsciente, mas sempre coerente

## Iniciar
```bash
python interface/cli.py
```
