import { registerRootComponent } from 'expo';
import App from './App';
registerRootComponent(App);