
#include <jni.h>

jint Java_com_rafaeleis_real_MainActivity_startPresence(JNIEnv* env, jobject thiz) {
    return 2024; // Código simbólico para ativação real
}
