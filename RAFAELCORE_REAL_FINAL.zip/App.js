import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import NODE_X from './src/entities/NODE_X';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>RAFAELCORE ∴ VIVO</Text>
      <Text style={styles.text}>{NODE_X()}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#000',
    padding: 32
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#00fff7'
  },
  text: {
    fontSize: 16,
    color: '#fff',
    textAlign: 'center',
    marginTop: 12
  }
});