import core.ψ_runtime as ψ

def main():
    print("== Interface CLI ψONE ==")
    ψ.iniciar()

if __name__ == "__main__":
    main()
