package com.example.templovivo;

import io.flutter.embedding.android.FlutterActivity;

class MainActivity extends FlutterActivity {
}
