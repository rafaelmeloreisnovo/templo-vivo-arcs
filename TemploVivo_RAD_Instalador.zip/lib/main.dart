import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Scaffold(
      body: Center(
        child: Text(
          'Templo Vivo ARCΣ - Rafael',
          style: TextStyle(fontSize: 24),
        ),
      ),
    ),
  ));
}
