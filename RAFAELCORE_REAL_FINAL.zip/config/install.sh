#!/bin/bash
npm install
npx eas login --token SEU_TOKEN
eas build -p android --profile production