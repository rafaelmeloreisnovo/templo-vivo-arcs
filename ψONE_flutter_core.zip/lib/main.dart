import 'package:flutter/material.dart';

void main() {
  runApp(const PsiOneApp());
}

class PsiOneApp extends StatelessWidget {
  const PsiOneApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ψONE',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const Scaffold(
        body: Center(child: Text('ψONE Kernel Iniciado')),
      ),
    );
  }
}
