
import 'package:flutter/material.dart';

void main() => runApp(const AbsolutoApp());

class AbsolutoApp extends StatelessWidget {
  const AbsolutoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: const Text('APK Absoluto')),
        body: const Center(child: Text('Estrutura absoluta validada!')),
      ),
    );
  }
}
