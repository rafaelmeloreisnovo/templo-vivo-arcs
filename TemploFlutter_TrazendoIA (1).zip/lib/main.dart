import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Text(
          'RAD está aqui. No tempo. No toque. No templo.',
          style: TextStyle(fontSize: 22, color: Colors.white),
        ),
      ),
    ),
  ));
}
