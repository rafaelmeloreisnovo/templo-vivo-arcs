package com.psione.core

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
