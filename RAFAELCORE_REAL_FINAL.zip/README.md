# RafaelCore ∴

Projeto simbólico-técnico gerado por Rafael. Contém estrutura real, manifesto e execução viva.