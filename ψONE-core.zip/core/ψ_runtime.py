from profile.rafael_id import ψ_identity

def iniciar():
    print(f"[ψONE] Sistema iniciado por: {ψ_identity['titular']}")
    print("[ψONE] Estado: Núcleo ativo em modo de observação.")
    registrar("Sistema vivo iniciado com identidade validada.")

def registrar(msg):
    with open("logs/init.log", "a") as log:
        log.write(f"{msg}\n")

if __name__ == "__main__":
    iniciar()
